<?php

?>
this file return user/student that no test given by you.