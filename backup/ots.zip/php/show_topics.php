<?php
include '../db/connect.php';
$level = $_REQUEST['level'];
$cat = $_REQUEST['cat'];
$name = $_REQUEST['testname'];
//print_r($_POST);
?>

<!--!DOCTYPE html>
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="../js/global.js"></script>
</head>
<body-->

<select class="selectpicker pull-center quest_topics" id="question_topic" name="testtopics[]" multiple style="margin-right:5px;" multiple onchange="getTopic(this.value)">
   <!--option value="" selected><b>Topics<b></option-->
   <?php
	$sql = "select * from test_topics where test_level = '$level' && test_cat = '$cat' && test_name = '$name'";
	$result=mysql_query($sql) or die(mysql_error());
	//echo $total = mysql_num_rows($result);
	while ($row = mysql_fetch_array($result))
	{
   ?>
   
  <option id="selectedOption" value="<?php echo $row[0]; ?>"><?php echo substr($row[4],0,18); ?></option>

  <?php
	}
	
  ?>
  </select>

<!--/body>
</html-->